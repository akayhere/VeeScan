import imutils

HAAR_CASCADE_PATH = "haarcascade_fullbody.xml"
try:
    human_cascade = cv2.CascadeClassifier(HAAR_CASCADE_PATH)
except Exception as e:
    print(f"Error loading Haar Cascade: {e}")
    print("Make sure 'haarcascade_fullbody.xml' is in the same directory or provide the full path.")
    exit()


cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("Error: Could not open video stream.")
    exit()

print("Webcam opened successfully. Press 'q' to quit.")

while True:
    ret, frame = cap.read()

    if not ret:
        print("Failed to grab frame, exiting...")
        break

    
    frame = imutils.resize(frame, width=min(800, frame.shape[1]))

    
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)


    people = human_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
 
    for (x, y, w, h) in people:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        cv2.putText(frame, "Person", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    cv2.imshow("Person Detection", frame)

    
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
print("Application closed.")    